module.exports = {
  validUser: {
    username: "standard_user",
    password: "secret_sauce",
  },

  lockoutUser: {
    username: "locked_out_user",
    password: "secret_sauce",
  },

  invalidUser: {
    username: "invalid_user",
    password: "invalid_password",
  },
};

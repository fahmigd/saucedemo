module.exports = {
  sort: {
    nameAsc: "az",
    nameDesc: "za",
    priceAsc: "lohi",
    priceDesc: "hilo",
  },
};
